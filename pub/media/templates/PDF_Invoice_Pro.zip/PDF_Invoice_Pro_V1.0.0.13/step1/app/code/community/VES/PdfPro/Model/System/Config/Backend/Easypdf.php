<?php

class VES_PdfPro_Model_System_Config_Backend_Easypdf extends Mage_Core_Model_Abstract
{
	
}