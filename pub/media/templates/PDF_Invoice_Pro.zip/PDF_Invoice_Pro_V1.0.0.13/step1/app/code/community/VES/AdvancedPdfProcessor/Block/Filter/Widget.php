<?php
class VES_AdvancedPdfProcessor_Block_Filter_Widget extends Mage_Adminhtml_Block_Template {
	
}