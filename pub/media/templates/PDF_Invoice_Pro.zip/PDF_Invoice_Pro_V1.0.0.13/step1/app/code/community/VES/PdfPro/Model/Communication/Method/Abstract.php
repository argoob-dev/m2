<?php

class VES_PdfPro_Model_Communication_Method_Abstract extends Varien_Object
{
	
}