<?php
$classFile = 'BCGean13.barcode.php';
$className = 'BCGean13';
$baseClassFile = 'BCGBarcode1D.php';
$codeVersion = '5.0.2';
?>