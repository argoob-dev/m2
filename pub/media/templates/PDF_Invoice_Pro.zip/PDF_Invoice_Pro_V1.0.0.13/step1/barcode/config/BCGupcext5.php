<?php
$classFile = 'BCGupcext5.barcode.php';
$className = 'BCGupcext5';
$baseClassFile = 'BCGBarcode1D.php';
$codeVersion = '5.0.2';
?>