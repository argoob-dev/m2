var config = {

paths: {
'select2': 'js/select2.min',
},

shim: {
'select2': {
  deps: ['jquery'],

           }
      }

};